import javax.swing.*;
import java.awt.*;

interface Console 
{
	JTextArea consoleField = new JTextArea();
	JFrame comFrame = new JFrame("SQL Executer");
	JFrame winFrame = new JFrame("Results");
	public void setConsole(String st);		
	Scrollbar scrollPane1 = new Scrollbar() ;
}